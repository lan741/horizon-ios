#version 330 core
in vec2 v_uv;
in vec3 v_normal;
out vec4 colour;
uniform sampler2D textureArray;
void main() {
    vec4 base = texture(textureArray, v_uv);
    float light = clamp(dot(normalize(v_normal), normalize(vec3(0.4, 1.0, 0.2))), 0.0, 1.0);
    if (base.a < 0.35) {
        discard;
    }
    colour = vec4(base.rgb * light, 1.0);
}
