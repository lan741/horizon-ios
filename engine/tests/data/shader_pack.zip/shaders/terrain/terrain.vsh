#version 330 core
layout(location = 0) in vec3 position;
layout(location = 1) in vec2 uv;
layout(location = 2) in vec3 normal;
out vec2 v_uv;
out vec3 v_normal;
uniform mat4 mvp;
uniform float time;
void main() {
    vec3 p = position + vec3(0.0, sin(time) * 0.02, 0.0);
    v_uv = uv;
    v_normal = normal;
    gl_Position = mvp * vec4(p, 1.0);
}
